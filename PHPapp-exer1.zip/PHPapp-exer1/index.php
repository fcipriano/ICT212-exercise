<html>
<?php require('header.php');?>
	<body>
		<div class="container">
			<!--Navigation bar-->
			<nav class="navbar navbar-inverse" role="navigation"> 
				<div class="navbar-header"> 
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse"> 
					<span class="sr-only">Toggle navigation</span> 
					<span class="icon-bar"></span> <span class="icon-bar"></span> 
					<span class="icon-bar"></span> 
					</button> 
					<a class="navbar-brand" href="#">PHP App</a> 
				</div> 
				<div class="collapse navbar-collapse" id="example-navbar-collapse"> 
					<ul class="nav navbar-nav navbar-right"> 
						<li class="active"><a href="#">Login</a></li> 
						<li><a href="#">Home</a></li> 
						<li class="dropdown"> 
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
								<span class="glyphicon glyphicon-cog"></span> <b class="caret"></b> 
							</a> 
							<ul class="dropdown-menu"> 
								<li><a href="#">Admin</a></li>
								<li><a href="#">Settings</a></li>
								<li class="divider"></li> 
								<li><a href="#">Help</a></li>
								<li><a href="#">About</a></li>								
								
							</ul>
						</li> 
					</ul> 
				</div> 
			</nav>
			<!--body content-->
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-lg-8">
						<div class="jumbotron">
							<div class="page-header">
							<h2>Welcome!<br/>
							<small>This is php a application</small>
							</h2>
							</div>
						</div>
					</div>
					<div class="col-md-1 col-lg-1">
					</div>
					<!--create form to submit username and password to server -->
					<!--remove the comment tag to enable the form tags-->
					<!--<form method="post" action="login.php">-->
						<div class="col-md-3 col-lg-3">
							<div class="well">
								<input type="text" placeholder="Username" name="username" class="form-control" /><br />
								<input type="password" placeholder="Password" name="password" class="form-control"/><br />
								<input type="submit" value="Login" class="btn btn-info btn-block" />
							</div>
						</div>
					<!--</form>-->
				</div>
			</div>
			
		</div>
		
	</body>
</html>
<?php
	require('footer.php');
?>