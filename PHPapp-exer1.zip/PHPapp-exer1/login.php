<?php
	//this gets the value entered from the input fields username and password
	//$_POST and $_GET uses the name of the field to get the value
	$uname = $_POST["username"];
	$pword = $_POST["password"];
	
	//calls the function to check credentials
	checkcredentials($uname,$pword);
	
	function checkcredentials($user,$pass){
		//checks if username and password is filled up properly
		//if the username and password is filled up, the page will be redirected to home.php
		if(strlen(trim($user))==0 || strlen(trim($pass))==0){
			echo "Fill up fields properly. Go back to login page <a href='index.php'>click here</a>";
		}else{
			header('Location:home.php');
		}
	}